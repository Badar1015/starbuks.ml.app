import streamlit as st
import pandas as pd
import joblib

st.set_page_config(page_title="Starbucks Calorie Predictor", page_icon="☕", layout="centered")

@st.cache_resource
def load_model():
    return joblib.load("starbucks_food_model.joblib")

model = load_model()

st.title("☕ Starbucks Calorie Category Predictor")
st.write("Enter the nutritional values below to predict whether an item is High Calorie or Low Calorie.")

fat = st.number_input("Fat (g)", min_value=0.0, value=5.0, step=0.5)
carb = st.number_input("Carb. (g)", min_value=0.0, value=30.0, step=1.0)
fiber = st.number_input("Fiber (g)", min_value=0.0, value=2.0, step=0.5)
protein = st.number_input("Protein (g)", min_value=0.0, value=5.0, step=0.5)

if st.button("Predict Calorie Category", type="primary"):
    input_data = pd.DataFrame([{
        "Fat (g)": fat,
        "Carb. (g)": carb,
        "Fiber (g)": fiber,
        "Protein (g)": protein
    }])

    prediction = model.predict(input_data)[0]

    if prediction == "High Calorie":
        st.warning(f"Prediction: {prediction}")
    else:
        st.success(f"Prediction: {prediction}")

st.caption("Prediction is based on the trained Decision Tree model.")
